import threading
import time
from typing import Any

from huggingface_hub import hf_hub_download
from llama_cpp import Llama
from llama_cpp.llama_speculative import LlamaPromptLookupDecoding

from sweep_autocomplete.config import (
    MODEL_FILENAME,
    MODEL_REPO,
    load_llama_runtime_config,
)
from loguru import logger

_model: Llama | None = None
_model_lock = threading.Lock()
_request_lock = threading.Lock()
_latest_request_id = 0


class RequestCancelled(Exception):
    """Raised when a queued request is superseded by a newer one."""
    pass


def get_model() -> Llama:
    global _model
    if _model is not None:
        return _model
    with _model_lock:
        if _model is None:
            runtime_config = load_llama_runtime_config()
            logger.info(f"Downloading model {MODEL_FILENAME} from {MODEL_REPO}")
            model_path = hf_hub_download(repo_id=MODEL_REPO, filename=MODEL_FILENAME)
            logger.info(f"Loading model from {model_path}")
            logger.info(f"llama.cpp runtime configuration: {runtime_config}")
            _model = Llama(
                model_path=model_path,
                **runtime_config.as_llama_kwargs(),
                draft_model=LlamaPromptLookupDecoding(num_pred_tokens=32),
                logits_all=True,
            )
            logger.info("Model loaded successfully")
    return _model


def generate_completion(
    prompt: str,
    stop: list[str],
    max_tokens: int,
    temperature: float,
    seed: int = 0,
    prefix: str = "",
    avoid_texts: list[str] = [],
) -> tuple[str, int, list[Any], str | None]:
    """Generate a completion using the local llama-cpp model.

    Only the latest request will actually run inference. If a newer request
    arrives while this one is waiting for the model lock, this request is
    cancelled (raises RequestCancelled). The generation itself is streamed
    token-by-token so a request that is superseded mid-generation is aborted
    immediately instead of occupying the GPU until it finishes.

    When avoid_texts is non-empty (a steered "next suggestion" request), the
    generation is retried with progressively higher temperature until the
    continuation no longer matches any avoided completion.

    Returns (completion_text, elapsed_ms, logprobs, finish_reason)
    matching the signature of fetch_next_edits_http.
    """
    global _latest_request_id

    model = get_model()
    full_prompt = prompt + prefix if prefix else prompt

    def _matches_avoided(continuation: str) -> bool:
        if not avoid_texts:
            return False
        candidates = [continuation]
        if prefix:
            candidates.append(prefix + continuation)
        for candidate in candidates:
            norm = candidate.strip()
            for avoided in avoid_texts:
                a = avoided.strip()
                if not a:
                    continue
                if norm == a or norm.startswith(a):
                    return True
        return False

    # Temperature ladder: the base sampling temperature first, then hotter
    # retries that can escape an overwhelmingly likely continuation token.
    temperatures = [temperature]
    if avoid_texts:
        temperatures += [0.8, 1.05]

    # Claim a request ID — always monotonically increasing
    with _request_lock:
        _latest_request_id += 1
        my_id = _latest_request_id

    # Wait for the model. When we get the lock, check if we're still latest.
    with _model_lock:
        if my_id != _latest_request_id:
            logger.info(f"Request {my_id} cancelled (latest is {_latest_request_id})")
            raise RequestCancelled()

        tokens = model.tokenize(full_prompt.encode("utf-8"))
        logger.info(f"Prompt length: {len(full_prompt)} chars, {len(tokens)} tokens, n_ctx={model.n_ctx()}")

        start = time.time()
        text = ""
        finish_reason = None
        for attempt, effective_temperature in enumerate(temperatures):
            parts: list[str] = []
            aborted = False
            stream = model.create_completion(
                prompt=full_prompt,
                max_tokens=max_tokens,
                temperature=effective_temperature,
                seed=seed,
                stop=stop,
                stream=True,
            )
            for chunk in stream:
                # A newer request arrived while this generation holds the
                # model: abort now so the GPU is released for it instead of
                # finishing a completion nobody will display.
                if my_id != _latest_request_id:
                    aborted = True
                    logger.info(
                        f"Request {my_id} aborted mid-generation "
                        f"(latest is {_latest_request_id})"
                    )
                    break
                choice = chunk["choices"][0]
                piece = choice.get("text") or ""
                if piece:
                    parts.append(piece)
                finish_reason = choice.get("finish_reason")
            if aborted:
                raise RequestCancelled()
            raw_text = "".join(parts)
            if attempt < len(temperatures) - 1 and _matches_avoided(raw_text):
                logger.info(
                    f"Avoided duplicate completion on attempt {attempt + 1}; "
                    f"retrying with temperature={temperatures[attempt + 1]}"
                )
                continue
            text = raw_text
            break
        elapsed_ms = int((time.time() - start) * 1000)

    if prefix:
        text = prefix + text

    return text, elapsed_ms, [], finish_reason
