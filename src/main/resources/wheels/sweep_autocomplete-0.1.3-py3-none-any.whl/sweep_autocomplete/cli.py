import argparse
import os


def _print_detection_report() -> None:
    from sweep_autocomplete.config import MODEL_FILENAME
    from sweep_autocomplete.hw_detect import detect_hardware, recommend_runtime_config

    snapshot = detect_hardware()
    print(f"RAM: total={snapshot.total_ram_mb} MB, free={snapshot.free_ram_mb} MB")
    if snapshot.gpus:
        for gpu in snapshot.gpus:
            memory = (
                f"VRAM {gpu.vram_total_mb}/{gpu.vram_free_mb} MB free"
                if gpu.vram_total_mb is not None
                else "VRAM unknown"
            )
            kind = "shared/integrated" if gpu.shared_memory else "dedicated"
            print(f"GPU: {gpu.name} [{gpu.vendor}, {kind}, {memory}]")
    else:
        print("GPU: none detected")

    model_file = os.environ.get("MODEL_FILENAME", MODEL_FILENAME)
    rec = recommend_runtime_config(snapshot, model_file)
    print(f"Model: {model_file}")
    print(
        f"Recommended: n_ctx={rec.n_ctx} n_batch={rec.n_batch} "
        f"n_gpu_layers={rec.n_gpu_layers} flash_attn={rec.flash_attn}"
    )
    print(f"Budget: {rec.budget_mb} MB — {rec.reason}")


def main():
    parser = argparse.ArgumentParser(description="Sweep Autocomplete Server")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8081, help="Bind port (default: 8081)")
    parser.add_argument(
        "--gpu-profile",
        choices=("default", "safe", "conservative", "auto"),
        default=os.environ.get("SWEEP_GPU_PROFILE", "default"),
        help="llama.cpp GPU profile (default: SWEEP_GPU_PROFILE or default)",
    )
    parser.add_argument(
        "--detect-only",
        action="store_true",
        help="Print detected hardware and the recommended llama.cpp settings, then exit",
    )
    args = parser.parse_args()

    # uvicorn imports the application after this function returns.  Set the
    # selected profile here so the same configuration path is used by the
    # console script and by direct application imports.
    os.environ["SWEEP_GPU_PROFILE"] = args.gpu_profile

    if args.detect_only:
        _print_detection_report()
        return 0

    import uvicorn

    uvicorn.run("sweep_autocomplete.app:app", host=args.host, port=args.port)
    return 0


if __name__ == "__main__":
    main()
