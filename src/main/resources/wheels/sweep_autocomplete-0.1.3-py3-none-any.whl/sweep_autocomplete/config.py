import os
import re
from dataclasses import dataclass
from typing import Mapping

from sweep_autocomplete.hw_detect import (
    HardwareSnapshot,
    detect_hardware,
    recommend_runtime_config,
)

NEXT_EDIT_AUTOCOMPLETE_ENDPOINT = os.environ.get(
    "NEXT_EDIT_AUTOCOMPLETE_ENDPOINT", None
)

MODEL_REPO = os.environ.get("MODEL_REPO", "sweepai/sweep-next-edit-0.5B")
MODEL_FILENAME = os.environ.get("MODEL_FILENAME", "sweep-next-edit-0.5b.q8_0.gguf")


@dataclass(frozen=True)
class LlamaRuntimeConfig:
    """Runtime settings passed to :class:`llama_cpp.Llama`.

    The default values intentionally match the values used before runtime
    configuration was exposed.  Profiles only provide defaults; an individual
    ``SWEEP_*`` setting always wins over its profile.  ``reason`` documents how
    the values were chosen (not passed to llama.cpp).
    """

    n_ctx: int
    n_batch: int
    n_gpu_layers: int
    flash_attn: bool
    reason: str = ""

    def as_llama_kwargs(self) -> dict[str, int | bool]:
        return {
            "n_ctx": self.n_ctx,
            "n_batch": self.n_batch,
            "n_gpu_layers": self.n_gpu_layers,
            "flash_attn": self.flash_attn,
        }


_GPU_PROFILES: dict[str, LlamaRuntimeConfig] = {
    # Keep the pre-0.1.1 behavior when no profile is selected.
    "default": LlamaRuntimeConfig(
        n_ctx=16384, n_batch=4096, n_gpu_layers=-1, flash_attn=True
    ),
    "safe": LlamaRuntimeConfig(
        n_ctx=4096, n_batch=512, n_gpu_layers=-1, flash_attn=True
    ),
    "conservative": LlamaRuntimeConfig(
        n_ctx=4096, n_batch=512, n_gpu_layers=16, flash_attn=False
    ),
}
_PROFILE_NAMES = (*_GPU_PROFILES, "auto")

_INTEGER_RE = re.compile(r"^[+-]?\d+$")
_TRUE_VALUES = {"1", "true", "yes", "on"}
_FALSE_VALUES = {"0", "false", "no", "off"}


def _parse_int(
    name: str,
    value: str | None,
    default: int,
    minimum: int,
) -> int:
    if value is None:
        return default
    value = value.strip()
    if not _INTEGER_RE.fullmatch(value):
        raise ValueError(f"{name} must be an integer, got {value!r}")
    parsed = int(value, 10)
    if parsed < minimum:
        raise ValueError(f"{name} must be >= {minimum}, got {parsed}")
    return parsed


def _parse_bool(name: str, value: str | None, default: bool) -> bool:
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in _TRUE_VALUES:
        return True
    if normalized in _FALSE_VALUES:
        return False
    accepted = "true/false, yes/no, on/off, or 1/0"
    raise ValueError(f"{name} must be {accepted}, got {value!r}")


def load_llama_runtime_config(
    environ: Mapping[str, str] | None = None,
    hardware: HardwareSnapshot | None = None,
) -> LlamaRuntimeConfig:
    """Load and validate llama.cpp settings from environment variables.

    ``SWEEP_GPU_PROFILE`` is applied first.  The four individual settings are
    then applied as overrides, which makes it possible to tune one value
    without losing the other safe-profile settings.

    With ``SWEEP_GPU_PROFILE=auto`` the profile is computed from detected
    hardware (GPU vendor/VRAM, free system RAM).  Pass ``hardware`` to inject
    a deterministic snapshot (used by tests); by default real detection runs.
    """

    environment = os.environ if environ is None else environ
    profile_name = environment.get("SWEEP_GPU_PROFILE", "default").strip().lower()

    if profile_name == "auto":
        snapshot = hardware if hardware is not None else detect_hardware()
        model_file = environment.get("MODEL_FILENAME", MODEL_FILENAME)
        recommended = recommend_runtime_config(snapshot, model_file)
        profile = LlamaRuntimeConfig(
            n_ctx=recommended.n_ctx,
            n_batch=recommended.n_batch,
            n_gpu_layers=recommended.n_gpu_layers,
            flash_attn=recommended.flash_attn,
            reason=f"auto: {recommended.reason} (budget {recommended.budget_mb} MB)",
        )
    else:
        try:
            profile = _GPU_PROFILES[profile_name]
        except KeyError as exc:
            available = ", ".join(_PROFILE_NAMES)
            raise ValueError(
                f"SWEEP_GPU_PROFILE must be one of {available}, got {profile_name!r}"
            ) from exc

    return LlamaRuntimeConfig(
        n_ctx=_parse_int("SWEEP_N_CTX", environment.get("SWEEP_N_CTX"), profile.n_ctx, 1),
        n_batch=_parse_int(
            "SWEEP_N_BATCH", environment.get("SWEEP_N_BATCH"), profile.n_batch, 1
        ),
        n_gpu_layers=_parse_int(
            "SWEEP_N_GPU_LAYERS",
            environment.get("SWEEP_N_GPU_LAYERS"),
            profile.n_gpu_layers,
            -1,
        ),
        flash_attn=_parse_bool(
            "SWEEP_FLASH_ATTN", environment.get("SWEEP_FLASH_ATTN"), profile.flash_attn
        ),
        reason=profile.reason,
    )


# A descriptive alias for callers that prefer the getter naming convention.
get_llama_runtime_config = load_llama_runtime_config
