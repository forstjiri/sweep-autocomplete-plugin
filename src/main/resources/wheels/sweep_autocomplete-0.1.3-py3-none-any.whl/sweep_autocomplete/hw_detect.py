"""Best-effort hardware detection for automatic llama.cpp tuning.

Every helper degrades gracefully to ``None``/empty values when a source is
unavailable, so callers can always fall back to conservative defaults.
Detection never raises: a misconfigured machine must still produce a usable
(but conservative) configuration.
"""

from __future__ import annotations

import ctypes
import os
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass

_CMD_TIMEOUT_S = 5

_PCI_VENDORS = {"0x1002": "amd", "0x10de": "nvidia", "0x8086": "intel", "0x106b": "apple"}


@dataclass(frozen=True)
class GpuInfo:
    vendor: str  # "nvidia" | "amd" | "intel" | "unknown"
    name: str
    vram_total_mb: int | None = None
    vram_free_mb: int | None = None
    # Integrated GPUs have little or no dedicated VRAM and fall back to system
    # memory (GTT/shared), which we cannot measure precisely.
    shared_memory: bool = False


@dataclass(frozen=True)
class HardwareSnapshot:
    gpus: tuple[GpuInfo, ...] = ()
    free_ram_mb: int | None = None
    total_ram_mb: int | None = None


@dataclass(frozen=True)
class RecommendedRuntime:
    n_ctx: int
    n_batch: int
    n_gpu_layers: int
    flash_attn: bool
    budget_mb: int
    reason: str


def _run(cmd: list[str]) -> str | None:
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=_CMD_TIMEOUT_S)
        if out.returncode != 0:
            return None
        return out.stdout
    except (OSError, subprocess.SubprocessError):
        return None


def _read(path: str) -> str | None:
    try:
        with open(path) as fh:
            return fh.read().strip()
    except OSError:
        return None


def _meminfo_linux() -> tuple[int | None, int | None]:
    content = _read("/proc/meminfo")
    if not content:
        return None, None
    total = free = None
    for line in content.splitlines():
        if line.startswith("MemTotal:"):
            total = int(line.split()[1]) // 1024
        elif line.startswith("MemAvailable:"):
            free = int(line.split()[1]) // 1024
    return total, free


def _memory_windows() -> tuple[int | None, int | None]:
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    stat = MEMORYSTATUSEX()
    stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
    try:
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return None, None
    except AttributeError:
        return None, None
    return stat.ullTotalPhys // (1024 * 1024), stat.ullAvailPhys // (1024 * 1024)


def detect_ram() -> tuple[int | None, int | None]:
    """Return (total_mb, free_mb); either may be None if undetectable."""
    system = platform.system()
    if system == "Linux":
        return _meminfo_linux()
    if system == "Windows":
        return _memory_windows()
    if system == "Darwin":
        out = _run(["sysctl", "-n", "hw.memsize"])
        if out and out.strip().isdigit():
            return int(out.strip()) // (1024 * 1024), None
    return None, None


def _nvidia_gpus() -> list[GpuInfo]:
    out = _run(
        [
            "nvidia-smi",
            "--query-gpu=name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ]
    )
    if not out:
        return []
    gpus: list[GpuInfo] = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) != 3:
            continue
        try:
            gpus.append(
                GpuInfo(
                    vendor="nvidia",
                    name=parts[0],
                    vram_total_mb=int(float(parts[1])),
                    vram_free_mb=int(float(parts[2])),
                )
            )
        except ValueError:
            continue
    return gpus


def _linux_sysfs_gpus() -> list[GpuInfo]:
    base = "/sys/class/drm"
    try:
        cards = sorted(d for d in os.listdir(base) if re.fullmatch(r"card\d+", d))
    except OSError:
        return []
    gpus: list[GpuInfo] = []
    for card in cards:
        dev = os.path.join(base, card, "device")
        vendor = _read(os.path.join(dev, "vendor"))
        if vendor is None:
            continue
        gpu_vendor = _PCI_VENDORS.get(vendor, "unknown")
        if gpu_vendor == "unknown":
            continue
        name = _read(os.path.join(dev, "product_name")) or card
        total = _read(os.path.join(dev, "mem_info_vram_total"))
        free = _read(os.path.join(dev, "mem_info_vram_free"))
        total_mb = int(total) // (1024 * 1024) if total else None
        free_mb = int(free) // (1024 * 1024) if free else None
        # APUs expose little/no dedicated VRAM and use shared system memory.
        shared = total_mb is None or free_mb is None or total_mb < 1024
        gpus.append(
            GpuInfo(
                vendor=gpu_vendor,
                name=name,
                vram_total_mb=total_mb,
                vram_free_mb=free_mb,
                shared_memory=shared,
            )
        )
    return gpus


def _lspci_gpus() -> list[GpuInfo]:
    if not shutil.which("lspci"):
        return []
    out = _run(["lspci"])
    if not out:
        return []
    gpus: list[GpuInfo] = []
    for line in out.splitlines():
        if not re.search(r"VGA compatible controller|Display controller|3D controller", line):
            continue
        low = line.lower()
        if "nvidia" in low:
            vendor = "nvidia"
        elif "amd" in low or "ati" in low or "radeon" in low:
            vendor = "amd"
        elif "intel" in low:
            vendor = "intel"
        else:
            vendor = "unknown"
        name = line.split(":", 2)[-1].strip()
        gpus.append(GpuInfo(vendor=vendor, name=name, shared_memory=True))
    return gpus


def detect_gpus() -> list[GpuInfo]:
    gpus = _nvidia_gpus()
    if gpus:
        return gpus
    if platform.system() == "Linux":
        gpus = _linux_sysfs_gpus()
    if not gpus:
        gpus = _lspci_gpus()
    return gpus


def detect_hardware() -> HardwareSnapshot:
    total, free = detect_ram()
    return HardwareSnapshot(gpus=tuple(detect_gpus()), free_ram_mb=free, total_ram_mb=total)


# --- Sizing heuristics ------------------------------------------------------
#
# Approximate per-model footprints for the shipped GGUF files:
# (model size in MB, KV-cache bytes per token at f16, vocab size).
# The logits buffer with logits_all=True costs vocab * n_batch * 4 bytes,
# which is why the historical n_batch=4096 needed ~2.5 GB by itself.
_MODEL_FOOTPRINTS = {
    "0.5b": (560, 2 * 24 * 896 * 2, 151_936),
    "1.5b": (1700, 2 * 28 * 1536 * 2, 151_936),
}
_DEFAULT_FOOTPRINT = (560, 2 * 24 * 896 * 2, 151_936)

# Compute buffers, fragmentation, draft-model lookup, process overhead.
_OVERHEAD_MB = 320
_DEDICATED_HEADROOM = 0.85
_SHARED_HEADROOM = 0.40

_CTX_CANDIDATES = (16384, 8192, 4096, 2048)
_BATCH_CANDIDATES = (4096, 2048, 1024, 512, 256)
# Integrated GPUs observed crashing with large logits buffers (Vulkan),
# so the batch is capped more strictly for shared-memory devices.
_SHARED_BATCH_CANDIDATES = (1024, 512, 256)


def _footprint(model_filename: str) -> tuple[int, int, int]:
    low = model_filename.lower()
    for key, value in _MODEL_FOOTPRINTS.items():
        if key in low:
            return value
    return _DEFAULT_FOOTPRINT


def _needed_mb(model_mb: int, kv_per_token: int, vocab: int, n_ctx: int, n_batch: int) -> float:
    kv_mb = kv_per_token * n_ctx / (1024 * 1024)
    logits_mb = vocab * n_batch * 4 / (1024 * 1024)
    return model_mb + kv_mb + logits_mb + _OVERHEAD_MB


def recommend_runtime_config(
    snapshot: HardwareSnapshot,
    model_filename: str,
) -> RecommendedRuntime:
    """Pick the largest (n_ctx, n_batch) that fits the detected memory budget.

    Dedicated GPUs use free VRAM; integrated/shared-memory GPUs use a fraction
    of available system RAM because the OS, IDE and browser also compete for
    it. When nothing fits comfortably the model is kept on the CPU with a
    small context.
    """

    model_mb, kv_per_token, vocab = _footprint(model_filename)

    discrete = [g for g in snapshot.gpus if not g.shared_memory and g.vram_free_mb]
    batch_candidates = _BATCH_CANDIDATES
    if discrete:
        gpu = max(discrete, key=lambda g: g.vram_free_mb or 0)
        budget = int(gpu.vram_free_mb * _DEDICATED_HEADROOM)
        reason = f"dedicated GPU: {gpu.name} ({gpu.vram_free_mb} MB free VRAM)"
    elif snapshot.free_ram_mb:
        budget = int(snapshot.free_ram_mb * _SHARED_HEADROOM)
        batch_candidates = _SHARED_BATCH_CANDIDATES
        gpu_names = ", ".join(g.name for g in snapshot.gpus) or "no GPU detected"
        reason = f"shared/integrated memory: {gpu_names}, {snapshot.free_ram_mb} MB RAM available"
    else:
        budget = 0
        reason = "hardware detection unavailable; conservative defaults"

    for n_ctx in _CTX_CANDIDATES:
        for n_batch in batch_candidates:
            if budget and _needed_mb(model_mb, kv_per_token, vocab, n_ctx, n_batch) <= budget:
                return RecommendedRuntime(n_ctx, n_batch, -1, True, budget, reason)

    return RecommendedRuntime(2048, 256, 0, True, budget, reason)
